<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

$uid=formget("uid");
$sid=formget("sid");

$errors=array();

$chSite=mysql_query("SELECT * FROM sites WHERE id='$sid' AND userid='$uid'");
$chSblock=mysql_fetch_array(mysql_query("SELECT * FROM sites WHERE id='$sid'"));

if(empty($sid)){
 $errors[]='Site is Empty!';
}
if(empty($uid)){
 $errors[]='User is Empty!';
}
if(mysql_num_rows($chSite)<1){
 $errors[]='Site Not Found!';
}
if($chSblock["status"]=="BLOCKED"){
 $errors[]='Site is Blocked';
}


if(empty($errors)){

  $getAds=mysql_query("SELECT * FROM advertises WHERE status='RUNNING' ORDER BY rand() LIMIT 0,1");

  $ip=$_SERVER["REMOTE_ADDR"];
  $ua=$_SERVER["HTTP_USER_AGENT"];
  $ref=$_SERVER["HTTP_REFERER"];

  while($Ads=mysql_fetch_array($getAds)){

   $AdsOwner=$Ads["userid"];
   $AdsId=$Ads["id"];
   $OwnerBal=mysql_fetch_array(mysql_query("SELECT * FROM userdata WHERE id='$AdsOwner'"));
   
   if($OwnerBal["adbalance"]<0.004){
      mysql_query("UPDATE advertises SET status='Paused' WHERE id='$AdsId'");
   }
   else {
      $_SESSION["ip"]=$ip;
      $_SESSION["ua"]=$ua;
      $_SESSION["ref"]=$ref;
      $_SESSION["uid"]=$uid;
      $_SESSION["sid"]=$sid;
      $_SESSION["aid"]=$AdsId;
      
      $rand="".rand(1,9)."".rand(0,9)."".rand(0,9)."".rand(0,9)."".rand(0,9)."".rand(0,9)."";
      
      $_SESSION["hash"]=$rand;

      if($Ads["type"]=="text"){
      $pr='<a href="http://adunion.x20.asia/show/click.php?s='.$rand.'">'.$Ads["name"].'</a>';
      }
      else {
      $pr='<a href="http://adunion.x20.asia/show/click.php?s='.$rand.'"><img src="'.$Ads["name"].'" alt="Please Wait.."/></a>';

      }
   }
   }

   echo 'document.write(\''.$pr.'\');';

}
else {

foreach($errors as $error){
echo 'document.write(\''.$error.'\');';
}
}
include '../pop.js';
$date=date("d-m-Y");
$chimp=mysql_query("SELECT * FROM imp WHERE uid='$uid' AND date='$date'");
$chimpc=mysql_fetch_array($chimp);
if(mysql_num_rows($chimp)>0){
$newimp=($chimpc["imp"]+1);
mysql_query("UPDATE imp SET imp='$newimp' WHERE uid='$uid' AND date='$date'");
}
else {
mysql_query("INSERT INTO imp (uid,imp,date) VALUES ('$uid',1,'$date')");
}

header('Content-type: application/js');
?>

  