<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - SET Country");

if($adminlog==1){
 
 $aid=formget("id");

if(isset($_POST['country'])){

 $ccode=formpost("country");
 $ccode.=",";
 
 $cset=mysql_query("UPDATE advertises SET country='$ccode',cset='yes' WHERE id='$aid'");
 if($cset){
   echo '<div class="success">Country SET successfully!</div>';
 }
 else {
  echo 'unk';
 }
 }
 echo '<div class="form"><form method="post">Country:<br/><textarea name="country"></textarea><br/><input type="submit" value="SET"/></form></div>';
 
 echo '<div class="ad"><a href="advd.php?id='.$aid.'">Advertises</a></div>';
 include '../foot.php';
 }
 else {
 header('Location:login.php');
 }
 ?>