<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName Cpa Campaign Statics");


if($adminlog==1){

$uid=formget("id");

echo '<div class="line">Cpa Total Earnings</div>';


$cp=mysql_fetch_array(mysql_query("SELECT * FROM userdata WHERE id='$uid'"));

$bal=$cp["cpabal"];

echo '<div class="ad">Your Total Cpa Earnings: <b id="num">'.$bal.'$ </b></div>';

echo '<div class="line">Cpa Campaign Report</div>';

echo '<div><table style="border-collapse:collapse;text-align:center;" align="center" height="60" border="1" bordercolor="#5b8ebb" cellpadding="5" width="90%">
<tbody><tr style="background-color:#5b8ebb">
<tr style="background-color:#5b8ebb">
<th>Date</th>
<th>Convertion</th>
<th>Earning</th>
<th>Details</th>
</tr>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*1;
$end=($start+7);



$all=mysql_query("SELECT * FROM cparepot WHERE userid='$uid' ORDER BY id DESC LIMIT $start,$end");


while($allr=mysql_fetch_array($all)){ 
 

$date=$allr["date"];
$amount=$allr["amount"];

$earning=$allr["earning"];

$total_action=mysql_num_rows(mysql_query("SELECT * FROM cparepot WHERE userid='$uid'"));



$today_action=mysql_num_rows(mysql_query("SELECT * FROM cparepot WHERE date='$date' AND userid='$uid'"));


echo '<tr bgcolor="#e8e8e8">
<td>'.$date.'</td>
<td>1</td>
<td>'.$amount.'$</b></td>
<td><a href="/cpa-details.php">Details</a></b></td>
</tr>';
}


$paid = mysql_query('SELECT *, SUM(amount) FROM cparepot WHERE userid="$uid"'); 
$paid2 = mysql_fetch_array($paid); 
$pay = $paid2['SUM(amount)'];

echo '<tr bgcolor="#bfc2c5"> 
<td height="28">Total</td>
<td><b id="num">'.$total_action.'</b></td>
<td><b id="num">'.$bal.'$</b></td>

<td><b id="num">N/A</b></td>
</tr>';

echo '</tbody></table></div>';

echo '<div class="back"><a href="index.php">Go Back To Home</a></div>';

include '../foot.php';

}
else {header('Location:index.php');
}
?>