<?php
include '../db.php';
include '../functions.php';

headtag("$SiteName - CPI Update");

if($adminlog==1){
echo '<div class="line">CPI Update</div>';

$datep=formpost("datep");
if(isset($_POST['datep'])) {


$update=$datep;
function makeSign($data,$apikey){
    ksort ($data);
    reset ($data);
    foreach($data as $k=>$v){
        $data[$k] = trim($v);
    }
    $s = implode("",$data);
    return md5($s.$apikey);
}
$data['acc']='exoclick143';
$data['sdate']=$update;
$data['edate']=$update;
$data['metrics']='bimei';
$data['dimensions']='date,pub,country';
$data['platform']='android';
$data['country']='IN';
$apikey='44c69d5b4ae3e0088418cefe00d3aae5';
$key=makeSign($data,$apikey);
$data = file_get_contents("http://data.union.ucweb.com/ExStatIntService?acc=exoclick143&key=$key&sdate=$update&edate=$update&metrics=bimei&dimensions=date,pub,country&platform=android&country=IN");

$data = str_replace('":{"IN":[{"bimei":','"',$data);
$data = str_replace('}]}','"',$data);

$alluser=mysql_query("SELECT * FROM userdata WHERE status='ACTIVE'");
while($alluserid=mysql_fetch_array($alluser)) {
$uid=$alluserid["id"];
$userpubbalance=$alluserid["pubalance"];
$useremail=$alluserid["email"];
$username=''.$alluserid["firstname"].' '.$alluserid["lastname"].'';
$cpireqck=mysql_query("SELECT * FROM cpireq WHERE userid='$uid' AND status='Approved'");
$cpirqdata=mysql_fetch_array($cpireqck);
if(mysql_num_rows($cpireqck)>0) {
$cpiaplist=mysql_query("SELECT * FROM appsrepot WHERE userid='$uid' AND reqid='$cpirqdata[id]' AND name='gps' AND status='Running'");
$cpilistdata=mysql_fetch_array($cpiaplist);
if(mysql_num_rows($cpiaplist)>0) {
$pub=$cpilistdata[pub];
preg_match('#'.$pub.'"(.*?)"#', $data, $matchs);
$install=$matchs[1];
$installall=$matchs[1];
if(empty($install)) {
$install=0;
$installall=0;
}
$vagthree=($install/3);
$vagexpld=explode(".", $vagthree);
$inscomi=$vagexpld[0];
$fainalinstall=($installall-$inscomi);
$totalearn=($fainalinstall*0.18);

$newbalance=($userpubbalance+$totalearn);

$cheakalredyupdateornot=mysql_query("SELECT * FROM appsrepot WHERE userid='$uid' AND reqid='$cpirqdata[id]' AND aplistid='$cpilistdata[id]' AND pub='$cpilistdata[pub]' AND install='$fainalinstall' AND earning='$totalearn' AND date='$datep' AND name='gps'");
$repotupdatenumber=mysql_num_rows($cheakalredyupdateornot);
if($repotupdatenumber==0) {
$repotads=mysql_query("INSERT INTO appsrepot (userid,reqid,aplistid,pub,install,earning,date,name) VALUES ('$uid','$cpirqdata[id]','$cpilistdata[id]','$cpilistdata[pub]','$fainalinstall','$totalearn','$datep','gps')");
$userbalanceupdate=mysql_query("UPDATE userdata SET pubalance='$newbalance' WHERE id='$uid'");

$subject='Adzincome.in - Low CPC Update Status';
$message='Hi, '.$name.' !
Wellcome to Adzincome.In
Now Your Publish Balance Is : '.$newbalance.' USD

Date '.$date.'
Clicks : '.$realclick.'
Earning : '.$earn.'
CPC : '.$cost.'

 
http://adzincome.in
Adzincome.In';
$headers='From: support@adzincome.in';
//mail($useremail,$subject,$message,$headers);
}
}
}
}
echo '<div class="success">All Update Successfull</div>';
}
else {
$vaste=date("Y-m-d");
echo '<form method="post">
<div class="uright">
<label for="datep">Date:</label><br />
<input type="text" name="datep" value="'.$vaste.'"/></div>
<div class="uright">
<input type="submit" value="See Preview" />
</div>
</form>';
}

echo '<div class="back"><a href="/admin">Go Back To Admin Home</a></div>';

include '../foot.php';
}
else {
header('Location:login.php');
}
?>
