<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName - 	
9apps CPI Detels");

if($adminlog==1){

echo '<div class="line">	
9apps CPI details</div>';

$rr=mysql_query("SELECT * FROM cpi WHERE status='Pending' ORDER BY id DESC");
while($re=mysql_fetch_array($rr))
{
$id=$re["id"];
$uid=$re["userid"];



echo '<div class="uright">
User ID : <a href="user.php?id='.$uid.'">'.$uid.'</a><br/>
Site Url : <font color="blue">'.$re["surl"].'</font><br/>
<div class="catRow">
<a href="spcpiaccept.php?id='.$id.'&uid='.$uid.'">Accept</a> - <a href="spcpireject.php?id='.$id.'&uid='.$uid.'">Reject</a></div>';
$stat=mysql_query("SELECT * FROM sites WHERE userid='$uid'");
while($show=mysql_fetch_array($stat)){
 echo '<div class="catRow">Url: <a href="site.php?id='.$show["id"].'">'.$show["url"].'</a></div>';
 }
echo '</div>';


}
echo '<div class="back"><a href="/admin">Go Back To Home</a></div>';

include '../foot.php';
}
else {
echo '<META http-equiv="refresh" content="0;URL=login.php">';
}
?>