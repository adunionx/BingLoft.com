<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Wall");

if($adminlog==1){

echo '<div class="title">Wall Service</div> <div class="ok"><font color="red"> Warning: </font> Dont Post any site link on wall otherwise you will be blocked from wall. </div>';
 
$act=formget("act");

 if($act=='del') {
$id=formget("id");
$sql=mysql_query("DELETE FROM wall WHERE id='$id'");
echo '<div class="success"> Deleted Successfully</div>';
}
//end del

if(isset($_POST['body'])){
$body=formpost("body");
$body=str_replace('[enter]','<br/>',$body);
$body=str_replace('[b]','<b>',$body);
$body=str_replace('[/b]','</b>',$body);
$date=date("l , F d , Y");
$addpost=mysql_query("INSERT INTO wall (firstname,body,time,status) VALUES ('none','$body','$date','Approved')");
if($addpost){
echo '<div class="success">Post Added successfully!</div>';
}
else {
echo 'unl';
}

}

echo '<div class="form"><form method="post">Post On Wall:<br/><textarea name="body"></textarea><br/><input type="submit" value="Post Now"/></form></div>';


$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

$wallss=mysql_query("SELECT * FROM wall ORDER BY id DESC LIMIT $start,$end");
 
 while($wall=mysql_fetch_array($wallss)){
  $nid=$wall["id"];
  $comments=mysql_num_rows(mysql_query("SELECT * FROM comments WHERE commentid='$nid'"));

 
$uidd=$wall["firstname"]; 

if($uidd=="none")

{ $uidd='Admin';
} 


  echo '<div class="saytop" align="left"><table width="100%"><tbody><tr><td align="left" width="32px"><img src="http://earnbuzz.in/web/profile.png" width="32px" class="ta"></td><td><b> '.$uidd.'</b><br> <img src="http://earnbuzz.in/web/offline.gif" alt="image"> </td><td align="right">'.$wall["time"].'</td></tr></tbody></table><div class="text"><b style="color:green;">'.$wall["body"].'</b><br> <br><div class="pages"> <a href="?act=del&id='.$wall["id"].'"><font color="blue">Delete</font></a> | <a href="comments.php?id='.$wall["id"].'"><font color="blue">Comments('.$comments.')</font></a> </div></div> </div><br/>'; 
 }
 echo '<div class="uright"><a href="?page='.($start+1).'">Next</a></div>';

 echo '<br/><a href="index.php"><div class="back">Home</div></a>';

 include '../foot.php';

}
else {
header('Location:index.php');
}
?>