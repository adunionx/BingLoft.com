<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Invoice Details");

if($adminlog==1){

 $iid=formget("id");

 $indata=mysql_fetch_array(mysql_query("SELECT * FROM bank WHERE id='$iid'"));
 $indata=mysql_fetch_array(mysql_query("SELECT * FROM invoice WHERE id='$iid'"));

$rsa=$indata["amount"];
$dmt=($rsa/60);

 echo '<div class="title">INVOICE #'.$iid.'</div>';
 echo '<div class="uright"><b>Amount:</b> Rs. '.$rsa.' ('.$dmt.'$ )<br/><b>Method:</b> '.$indata["method"].'<br/><b>Via:</b> '.$indata["via"].'<br/><b>Created On:</b> '.$indata["time"].'<br/><b>Status:</b> '.$indata["status"].'<br/><b>Created By:</b> <a href="user.php?id='.$indata["userid"].'">USER#'.$indata["userid"].'</a><br/><br/><b>ACTIONS:</b><br/>- <a href="addbal.php?id='.$indata["id"].'">Approve Invoice</a><br/>- <a href="pay.php?id='.$indata["id"].'">Pay Invoice</a> - <a href="reject.php?id='.$indata["id"].'">Reject Invoice</a> - <a href="cancel.php?id='.$indata["id"].'">Cencel Invoice</a> - <a href="bcancel.php?id='.$indata["id"].'">Bcencel Invoice</a> - <a href="aprvcnl.php?id='.$indata["id"].'">Cencel Apprv </a></div>';

 echo '<a href="invoice.php"><div class="back">INVOICES</div></a>';
 include '../foot.php';
 }
 else {
 header('Location:login.php');
 }
 ?>