<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Panel Beta");

if($adminlog==1){

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

 $invoice=mysql_query("SELECT * FROM adinvoice WHERE status='Pending' ORDER BY id DESC LIMIT $start,$end");

 while($invoices=mysql_fetch_array($invoice)){
  echo '<div class="uright">APRVINVO#'.$invoices["id"].'<br/>Amount: '.$invoices["amount"].'<br/>Method: '.$invoices["method"].'$<br/>Created by: <a href="user.php?id='.$invoices["userid"].'">USER#'.$invoices["userid"].'</a><br/>Checked? <a href="payad.php?id='.$invoices["id"].'">Pay Aapproved</a> - <a href="blockadi.php?id='.$invoices["id"].'">Reject Aprov</a></div>';
  }

 echo '<div class="uright"><a href="?page='.($page+1).'">Next</a></div>';
echo '<a href="index.php?redir=unpay"><div class="back">Home</div></a>';

include '../foot.php';

}
else {

header('Location:/login.php?error=ticket&reason=session');
}

?>