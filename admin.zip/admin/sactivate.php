<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';
 
header("$SiteName - Active Site");

if($adminlog==1){

 $sid=formget("id");

 $doit=mysql_query("UPDATE sites SET status='Active' WHERE id='$sid'");
 if($doit){
  echo '<div class="success">Site Activated Successfully!</div>';
 }
 else {
  echo '<div class="error">Unknown Error!</div>';
 }
 
 echo '<a href="site.php?id='.$sid.'"><div class="ua">SITES</div></a>';
 include '../foot.php';
 }
 else {
  header('Location:login.php');
 }
 ?>