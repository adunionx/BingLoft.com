<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Validate refs");

if($adminlog==1){

 $vid=formget("vid");
 
 $doit=mysql_query("UPDATE affiliates SET status='VALID' WHERE id='$vid'");
 if($doit)
{

   echo '<div class="success">Successfully validated!</div>';
}
 else {
  echo 'Unknown error';
 }
echo '<a href=""><div class="back">HOME</div></a>'; 

 include '../foot.php';

 }
 else {
 header('Location:login.php');
 }
?>