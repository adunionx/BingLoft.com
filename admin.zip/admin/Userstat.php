<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Clicks details");

if($adminlog==1){

$sid=formget("sid");
echo '<div class="title">Statistic Report</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

$stat=mysql_query("SELECT * FROM clicks WHERE siteid='$sid' ORDER BY id DESC LIMIT $start,$end");

include_once('../country/ip2country.php');
$ip2c=new ip2country();
$ip2c->mysql_host='localhost';
$ip2c->db_user='anilwapc_anil';
$ip2c->db_pass='lolbaba@9087#ak)';
$ip2c->db_name='anilwapc_data';
$ip2c->table_name='ip2c';
if(mysql_num_rows($stat)>0){
while($show=mysql_fetch_array($stat)){
echo '<div class="uright">Date: '.$show["time"].'<br/>IP: '.$show["ip"].'<br/>User Agent: '.$show["ua"].'<br/>Country: '. $ip2c->get_country_name($show["ip"]) . ' <br/>Type: '.$show["status"].'</div>';
}

echo '<div class="uright"><a href="Userstat.php?sid='.$sid.'/'.($start+1).'">Next</a></div>';
}
else {
echo '<div class="error">There is no clicks!</div>';
}

echo '<div class="back"><img src="/home.png"/> <a href="index.php">Home</a> | <a href="index.php">Admin</a></div>';

include '../foot.php';


}

else {

header('Location:/');
}
?>
