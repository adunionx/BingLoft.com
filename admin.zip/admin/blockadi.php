<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Block Invoice");

if($adminlog==1){

 $vid=formget("id");

$doit=mysql_query("UPDATE adinvoice SET status='Rejected' WHERE id='$vid'");
   echo '<div class="success">Successfully validated!</div>';
echo '<a href="unadinvo.php"><div class="back">HOME</div></a>'; 

 include '../foot.php';

 }
 else {
 header('Location:login.php');
 }
?>