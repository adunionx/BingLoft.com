<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - News reply");

if($adminlog==1){

echo '<div class="title">Add news</div>';

if(isset($_POST['title']) AND isset($_POST['body'])){
$title=formpost("title");
$body=formpost("body");
$body=str_replace('[enter]','<br/>',$body);
$body=str_replace('[b]','<b>',$body);
$body=str_replace('[/b]','</b>',$body);
$date=date("l , F d , Y");
$addnews=mysql_query("INSERT INTO news (title,body,time) VALUES ('$title','$body','$date')");
if($addnews){
echo '<div class="success">News Added successfully!</div>';
}
else {
echo 'unl';
}
}
echo '<div class="form"><form method="post">Title:<br/><input type="text" name="title"/><br/>Message:<br/><textarea name="body"></textarea><br/><input type="submit" value="Add"/></form><br/>* [b] [/b] to bold<br/>* [enter] to line down</div>';

echo '<a href="news.php"><div class="ua">All NEWS</div></a>';
include '../foot.php';
}
else {
header('Location:login.php');
}
?>
