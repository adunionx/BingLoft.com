<?php
include '../db.php';
include '../functions.php';

headtag("$SiteName - CPImh Update");

if($adminlog==1){
echo '<div class="line">cpif Update</div>';

$datep=formpost("datep");
if(isset($_POST['datep'])) {
echo '<table style="border-collapse:collapse;text-align:center;" border="1" bordercolor="#5b8ebb" height="60" cellpadding="5" align="center">
<tr style="background-color:#5b8ebb">
<th>Date</th>
<th>Install</th>
<th>Earning</th>
<th>User Balance</th>
<th>Total User Balance</th>
<th>User ID</th>
</tr>';

$update=$datep;
function makeSign($data,$apikey){
    ksort ($data);
    reset ($data);
    foreach($data as $k=>$v){
        $data[$k] = trim($v);
    }
    $s = implode("",$data);
    return md5($s.$apikey);
}
$data['acc']='exoclick143';
$data['sdate']=$update;
$data['edate']=$update;
$data['metrics']='bimei';
$data['dimensions']='date,pub,country';
$data['platform']='android';
$data['country']='IN';
$apikey='44c69d5b4ae3e0088418cefe00d3aae5';
$key=makeSign($data,$apikey);
$data = file_get_contents("http://data.union.ucweb.com/ExStatIntService?acc=exoclick143&key=$key&sdate=$update&edate=$update&metrics=bimei&dimensions=date,pub,country&platform=android&country=IN");

$data = str_replace('":{"IN":[{"bimei":','"',$data);
$data = str_replace('}]}','"',$data);

$alluser=mysql_query("SELECT * FROM userdata WHERE status='ACTIVE'");
while($alluserid=mysql_fetch_array($alluser)) {
$uid=$alluserid["id"];
$userpubbalance=$alluserid["pubalance"];
$useremail=$alluserid["email"];
$username=''.$alluserid["firstname"].' '.$alluserid["lastname"].'';
$cpireqck=mysql_query("SELECT * FROM cpireq WHERE userid='$uid' AND status='Approved'");
$cpirqdata=mysql_fetch_array($cpireqck);
if(mysql_num_rows($cpireqck)>0) {
$cpiaplist=mysql_query("SELECT * FROM appslist WHERE userid='$uid' AND reqid='$cpirqdata[id]' AND name='gps' AND status='Running'");
$cpilistdata=mysql_fetch_array($cpiaplist);
if(mysql_num_rows($cpiaplist)>0) {
$pub=$cpilistdata[pub];
preg_match('#'.$pub.'"(.*?)"#', $data, $matchs);
$install=$matchs[1];
$installall=$matchs[1];
if(empty($install)) {
$install=0;
$installall=0;
}
$vagthree=($install/3);
$vagexpld=explode(".", $vagthree);
$inscomi=$vagexpld[0];
$fainalinstall=($installall-$inscomi);
$totalearn=($fainalinstall*0.12);

$newbalance=($userpubbalance+$totalearn);

$cheakalredyupdateornot=mysql_query("SELECT * FROM appsrepot WHERE userid='$uid' AND reqid='$cpirqdata[id]' AND aplistid='$cpilistdata[id]' AND pub='$cpilistdata[pub]' AND install='$fainalinstall' AND earning='$totalearn' AND date='$datep' AND name='gps'");
echo '<tr bgcolor="#e8e8e8">
<td>'.$datep.'</td>
<td><b id="num">'.$fainalinstall.'</b></td>
<td><b id="num">'.$totalearn.' $</b></td>
<td><b id="num">'.$userpubbalance.'</b></td>
<td><b id="num">'.$newbalance.'</b></td>
<td><b><a href="sper.php?id='.$uid.'">'.$username.'</a></b></td>
</tr>';
}
}
}
echo '</table>';
}
else {
$vaste=date("Y-m-d");
echo '<form method="post">
<div class="uright">
<label for="datep">Date:</label><br />
<input type="text" name="datep" value="'.$vaste.'"/></div>
<div class="uright">
<input type="submit" value="See Preview" />
</div>
</form>';
}

echo '<div class="back"><a href="/admin">Go Back To Admin Home</a></div>';

include '../foot.php';
}
else {
header('Location:login.php');
}
?>
