<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Validate Invoice");

if($adminlog==1){

 $vid=formget("id");

 $date=date("d-m-Y");
 $doit=mysql_query("UPDATE invoice SET status='Approved on $date' WHERE id='$vid'");
 if($doit){
   $get_use=mysql_query("SELECT * FROM invoice WHERE id='$vid'");
   $get_us=mysql_fetch_array($get_use);
   $uid=$get_us["userid"];
   $get_u=mysql_query("SELECT * FROM userdata WHERE id='$uid'");
   $get_user=mysql_fetch_array($get_u);
 $userd=mysql_fetch_array(mysql_query("SELECT * FROM userdata WHERE id='$uid'")); 

$balance=$userd["adbalance"];   $adm=$get_us["amount"];
$newbal=($balance+$adm);
   $doit=mysql_query("UPDATE userdata SET adbalance='$newbal' WHERE id='$uid'");


 $addnote=mysql_query("INSERT INTO msgs (rid,body,status) VALUES ('$uid','Your balance has been Approved.','New')");

   $emailz=$get_user["email"];
   echo '<div class="success">Successfully validated!</div>';
       $to      = $emailz;
    $subject = 'Your Approve Balance Invoice Has Approved';
    $message = 'Dear '.$get_user["firstname"].',
We are happy to tell you that your Approved Balance #Aprv'.$vid.' has been successfully Approved.

Your Approved Amount: '.$get_us["amount"].'

Thank You!


Support:
natanray321@gmail.com
+917384087247

Thanks,
AdUnion Team,
AdUnion Pvt. Ltd.';
    $headers = 'From: AdUnion - Ad Network<natanray321@gmail.com>' . "\r\n" .
    'Reply-To: natanray321@gmail.com' . "\r\n" .
    'X-Mailer: AdUnion';

    mail($to, $subject, $message, $headers);
 }
 else {
  echo 'Unknown error';
 }
echo '<a href="unpayinvo.php"><div class="ua">HOME</div></a>'; 

 include '../foot.php';

 }
 else {
 header('Location:login.php');
 }
?>