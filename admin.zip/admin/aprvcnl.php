<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Block Invoice");

if($adminlog==1){

 $vid=formget("id"); 

$doit=mysql_query("UPDATE invoice SET status='Canceled' WHERE id='$vid'");
 if($doit){
   $get_use=mysql_query("SELECT * FROM invoice WHERE id='$vid'");
   $get_us=mysql_fetch_array($get_use);
   $uid=$get_us["userid"];
   $get_u=mysql_query("SELECT * FROM userdata WHERE id='$uid'");
   $get_user=mysql_fetch_array($get_u);
 $userd=mysql_fetch_array(mysql_query("SELECT * FROM userdata WHERE id='$uid'")); 

$balance=$userd["pubalance"];   
$dmt=$get_us["amount"];

$newbal=($balance+$dmt);
   $doit=mysql_query("UPDATE userdata SET pubalance='$newbal' WHERE id='$uid'");


 $addnote=mysql_query("INSERT INTO msgs (rid,body,status) VALUES ('$uid','Your Invoice has been Canceled Money Refunded.','New')");

   $emailz=$get_user["email"];
   echo '<div class="success">Successfully cencel!</div>';
       $to      = $emailz;
    $subject = 'Your Invoice Has Canceled';
    $message = 'Dear '.$get_user["firstname"].',
We are Sorry to tell you that your Invoice  #INV'.$vid.' has been Cenceled.

Your Refund Amount: '.$get_us["amount"].'

Thank You!


Support:
support@adzincome.in
+919782583610

Thanks,
AdzIncome Team,
AdzIncome.In';
    $headers = 'From: AdzIncome.In<support@adzincome.in>' . "\r\n" .
    'Reply-To: support@adzincome.in' . "\r\n" .
    'X-Mailer: AdzImcome';

    mail($to, $subject, $message, $headers);
 }
 else {
  echo 'Unknown error';
 }
echo '<a href="unadinvo.php"><div class="back">HOME</div></a>'; 

 include '../foot.php';

 }
 else {
 header('Location:login.php');
 }
?>