<html>
<title>Top Frauds</title>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<link rel="shortcut icon" href="pics/do.jpg" type="image/x-icon"/> 
<link href="../theme/style.css" rel="stylesheet" type="text/css" />
<?php include "../inc/def.php"; ?>

<?
  echo '<div class="blk">Top Frauds</div>';
// how many rows to show per page
$rowsPerPage = 10;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
    $pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;

$query = " SELECT * FROM users order by fraud desc  " . 
         " LIMIT $offset, $rowsPerPage ";
$result = mysql_query($query) or die('Error, query failed');

// print the random numbers
while($row = mysql_fetch_array($result))
{
   echo '<div class "lgn"><a href="profile.php?user='.$row['user'].'"> <b>'.$row['user'].'</b></a> fraud =  <b>'.$row['fraud'].'</b> &  Points = <b>'.$row['point'].'</b> Points</div>';

}
if ($pageNum > 1)
{
   $page  = $pageNum - 1;
   $prev  = " <a href=\"$self?page=$page\">[Prev]</a> ";

   $first = " <a href=\"$self?page=1\">[First Page]</a> ";
}
else
{
   $prev  = '&nbsp;'; // we're on page one, don't print previous link
   $first = '&nbsp;'; // nor the first page link
}

if ($pageNum < 100)
{
   $page = $pageNum + 1;
   $next = " <a href=\"$self?page=$page\">[Next]</a> ";

   $last = " <a href=\"$self?page=$maxPage\">[Last Page]</a> ";
}
else
{
   $next = '&nbsp;'; // we're on the last page, don't print next link
   $last = '&nbsp;'; // nor the last page link
}

// print the navigation link
echo $first . $prev . $nav . $next  ;

echo '<br><a href="index.php">BacK</a>';
include "../inc/footer.php";


?>