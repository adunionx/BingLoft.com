<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Advertises");

if($adminlog==1){

$uid=formget("id");
echo '<div class="title">Advertises of U#'.$uid.'</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

$stat=mysql_query("SELECT * FROM advertises WHERE userid='$uid' ORDER BY id DESC LIMIT $start,$end");

while($show=mysql_fetch_array($stat)){
 echo '<a href="advd.php?id='.$show["id"].'"><div class="ua">Url: '.$show["url"].'<br/>Site ID: '.$show["id"].'</div></a>';
 }


echo '<div class="ad"><a href="?page='.($start+1).'">Next</a></div>';


echo '<a href="user.php?id='.$uid.'"><div class="ua" align="center"><b>User Details</b></div></a>';

include '../foot.php';
}
else {

header('Location:login.php?error=session&out=no&valid=no&session=no');
}

?>
