<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Links");

if($adminlog==1){

echo '<div class="title">Promoting Links</div>';

$page=formget("page");

if(empty($page)){ $page=0; } $start=$page*10; $end=($start+10);

$link=mysql_query("SELECT * FROM promo ORDER BY id DESC LIMIT $start,$end");  while($show=mysql_fetch_array($link)){

  echo '<div class="catRow2">
    <b>link Url:</b> <font color="blue">'.$show["body"].'</font>
<br/>
Userid: '.$show["userid"].'

  </div>';
}
 echo '<div class="uright"><a href="?page='.($start+1).'">Next</a></div>';
 echo '<div class="back"><img src="/home.png"/> <a href="">Home</a> | <a href="index.php">Admin</a></div>';
 
 include '../foot.php';

}

else {

header('Location:/');

}

?>
