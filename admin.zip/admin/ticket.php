<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Reply tickets");

if($adminlog==1){

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);
$ticket=mysql_query("SELECT * FROM tickets WHERE status='Waiting for Admin\'s reply' ORDER BY id DESC LIMIT $start,$end");



echo '<div class="title">Support tickets</div>';

while($tickets=mysql_fetch_array($ticket)){

 echo '<div class="uright"><b>'.$tickets["title"].'</b><br/><small>'.$tickets["msg"].'<br/>By: <a href="user.php?id='.$tickets["userid"].'">USER#'.$tickets["userid"].'</a> </small><a href="reply.php?id='.$tickets["id"].'&uid='.$tickets["userid"].'">Reply</a></div>';

}

echo '<div class="uright"><a href="?page='.($page+1).'">Next</a></div>';
echo '<a href="index.php?redir=ticket"><div class="back">Home</div></a>';

include '../foot.php';

}
else {

header('Location:/login.php?error=ticket&reason=session');
}

?>
