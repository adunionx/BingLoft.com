<?php

include '../db.php';
include '../functions.php';

headtag("$SiteName Cpa Campaign Statics");


if($adminlog==1){




echo '<div class="line"> User Cpa Campaign Payment </div><br/>';

$act=formget("act");

 if($act=='paid') {


$allur=mysql_query("SELECT * FROM cparepot WHERE status='PENDING'");



 while($allt=mysql_fetch_array($allur)){


$amt=$allt["amount"];

$uid=$allt["userid"];

$sql=mysql_query("UPDATE cparepot SET status='Paid' WHERE userid='$uid'");


 $User=mysql_fetch_array(mysql_query("SELECT * FROM userdata WHERE id='$uid'"));

 $userbal=$User["pubalance"];

 $newU=($userbal+$amount);


 $addnote=mysql_query("INSERT INTO msgs (rid,body,status) VALUES ('$uid','Your Cpa Earnings has been Paid.','New')");


 $doIt=mysql_query("UPDATE userdata SET pubalance='$newU' WHERE id='$uid'");
if($doit AND addnote){
 echo '<div class="success">Cpa Balance  Successfully Paid</div>';

}

}
 } 

//end paid

echo '<center><a href="?act=paid"><b>Pay All Cpa Payment</b></a></center><br/>';

echo '<div class="line"> User Cpa Campaign Report </div><br/>';

echo '<div><table style="border-collapse:collapse;text-align:center;" align="center" height="60" border="1" bordercolor="#5b8ebb" cellpadding="5" width="90%">
<tbody><tr style="background-color:#5b8ebb">
<tr style="background-color:#5b8ebb">
<th>Date</th>
<th>Convertion</th>
<th>Earning</th>
<th>Userid</th>
<th>Payment</th>
<th>Details</th>
</tr>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*1;
$end=($start+30);

$allr=mysql_query("SELECT * FROM cparepot ORDER BY id DESC LIMIT $start,$end");



 while($allu=mysql_fetch_array($allr)){

echo '<tr bgcolor="#e8e8e8">
<td>'.$allu["date"].'</td>
<td>'.$allu["action"].'</td>
<td>'.$allu["earning"].'$</b></td>
<td><a href="user.php?id='.$allu["userid"].'">'.$allu["userid"].'</a></b></td>
<td>'.$allu["status"].'</b></td>
<td><a href="cpa-user.php?id='.$allu["userid"].'">Details</a></b></td>
</tr>';
}

$paid = mysql_query('SELECT *, SUM(amount) FROM cparepot'); 
$paid2 = mysql_fetch_array($paid); 
$pay = $paid2['SUM(amount)'];

$total_action=mysql_num_rows(mysql_query("SELECT * FROM cparepot"));

$earn=($total_action*$earning);

echo '<tr bgcolor="#bfc2c5"> 
<td height="28">Total</td>
<td><b id="num">'.$total_action.'</b></td>
<td><b id="num">'.$pay.'</b></td>
<td><b id="num">N/A</b></td>


<td><b id="num">N/A</b></td>
<td><b id="num">N/A</b></td>
</tr>';

echo '</tbody></table></div>';

echo '<div class="back"><a href="index.php">Go Back To Home</a></div>';

include '../foot.php';

}
else {header('Location:index.php');
}
?>