<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Ad details");

if($adminlog==1){

 $aid=formget("id");

$act=formget("act");

 if($act=='del') {

 $id=formget("id");

$sql=mysql_query("DELETE FROM advertisers WHERE id='$id'");
echo '<div class="success"> Deleted Successfully</div>';
}
//end del

 $addata=mysql_fetch_array(mysql_query("SELECT * FROM advertises WHERE id='$aid'"));

 echo '<div class="title">Advertise Details: #'.$addata["id"].'</div>';
 echo '<div class="uright"><b>Ad Name:</b> '.$addata["name"].'<br/><b>Url:</b> <a href="'.$addata["url"].'">'.$addata["url"].'</a><br/><b>Type:</b> '.$addata["type"].'<br/><b>Devices:</b> '.$addata["device"].' ('.$addata["dset"].') <a href="dset.php?id='.$addata["id"].'">Set</a><br/><b>Country:</b> '.$addata["country"].' ('.$addata["cset"].') <a href="cset.php?id='.$addata["id"].'">Set</a><br/><b>Status:</b> '.$addata["status"].'<br/><b>Owner:</b> <a href="user.php?id='.$addata["userid"].'">USER#'.$addata["userid"].'</a><br/><br/><b>ACTIONS:</b><br/>- <a href="pause.php?id='.$addata["id"].'">Pause Ad</a><br/>- <a href="run.php?id='.$addata["id"].'">Run Ad</a><br/>- <a href="refuse.php?id='.$addata["id"].'">Refuse Ad</a><br/>- <a href="?act=del&id='.$aid.'">Delete Ad</a></div>';

 echo '<a href="advertise.php"><div class="ua">Advertises</div></a>';
 include '../foot.php';
 }
 else {
 header('Location:login.php');
 }
 ?>