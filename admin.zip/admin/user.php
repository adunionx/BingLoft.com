<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - User Details");

if($adminlog==1){

 $uid=formget("id");

 $act=formget("act"); 

 if($act=='del') {

 $id=formget("id");

 $sql=mysql_query("DELETE FROM userdata WHERE id='$id'"); 

echo '<div class="success"> Deleted Successfully</div>';
 } 

//end del 

 $userd=mysql_query("SELECT * FROM userdata WHERE id='$uid'");
 $fuserd=mysql_fetch_array($userd);
 $sites=mysql_num_rows(mysql_query("SELECT * FROM sites WHERE userid='$uid'"));
 $advs=mysql_num_rows(mysql_query("SELECT * FROM advertises WHERE userid='$uid'"));
 $invoices=mysql_num_rows(mysql_query("SELECT * FROM invoice WHERE userid='$uid'"));

 $aff=mysql_num_rows(mysql_query("SELECT * FROM affiliates WHERE aid='$uid'"));

 echo '<div class="title">User Details ('.$fuserd["firstname"].')</div>';

 echo '<div class="uright"><b>User ID:</b> '.$fuserd["id"].'<br/><b>Firstname:</b> '.$fuserd["firstname"].'<br/><b>Lastname:</b> '.$fuserd["lastname"].'<br/><b>Address1:</b> '.$fuserd["address1"].'<br/><b>Address2:</b> '.$fuserd["address2"].'<br/><b>State/Region:</b> '.$fuserd["state"].'<br/><b>City:</b> '.$fuserd["city"].'<br/><b>Zip / Postal code:</b> '.$fuserd["zipcode"].'<br/><b>Country:</b> '.$fuserd["country"].'<br/><b>Mobile:</b> '.$fuserd["mobile"].'<br/><b>Email:</b> '.$fuserd["email"].' <a href="email.php?id='.$fuserd["id"].'">Edit</a><br/><b>Publisher Balance:</b> '.$fuserd["pubalance"].'$ (<a href="pub.php?id='.$fuserd["id"].'">Edit</a>)<br/><b>Advertiser Balance:</b> '.$fuserd["adbalance"].'$ (<a href="adv.php?id='.$fuserd["id"].'">Edit</a>)<br/><b>Cpa Balance:</b> '.$fuserd["cpabal"].'$ (<a href="ap.php?id='.$fuserd["id"].'">Edit</a>)<br/> <b>Sites:</b> <a href="usite.php?id='.$uid.'">'.$sites.'</a><br/><b>Advertises:</b> <a href="uadv.php?id='.$uid.'">'.$advs.'</a><br/><b>Invoices:</b> <a href="uinvo.php?id='.$uid.'">'.$invoices.'</a><br/><b>Total Reffers:</b> <a href="uaff.php?id='.$uid.'">'.$aff.'</a><br/><b>Status:</b> '.$fuserd["status"].'<br/><br/><b>ACTIONS:</b>

<br/>- <a href="blocku.php?id='.$uid.'">Block User</a><br/>- <a href="activateu.php?id='.$uid.'">Active User</a><br/> - <a href="appstat2.php?uid='.$uid.'">Apps Stats User</a> <br/> - <a href="mailu.php?id='.$uid.'">Mail User</a> <br/> - <a href="promoad.php?uid='.$uid.'">Add Link</a> <br/> - <a href="bwall.php?id='.$uid.'">Block from Wall</a> <br/> - <a href="notice.php?uid='.$uid.'">Notice </a> <br/> - <a href="awall.php?id='.$uid.'">Active from Wall</a> <br/> - <a href="?act=del&id='.$uid.'">Delete User</a> </div>';

 echo '<a href="index.php"><div class="back">Home</div></a>';
 include '../foot.php';

 }

 else {

 header('Location:login.php');
 }

?>