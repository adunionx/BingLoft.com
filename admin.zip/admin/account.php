<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Editing Account");

if($adminlog==1){

 echo '<div class="title">Edit Account</div>';

 $daTa=explode("|-pr-|",file_get_contents("admins/$admu-data.pra"));
 
 if(isset($_POST["email"]) AND isset($_POST["pwd"])){
  

  $memail=formpost("email");  
  $mpwd=formpost("pwd");

  $doIt=file_put_contents("admins/$admu-data.pra","$admu|-pr-|$memail|-pr-|$mpwd|-pr-|");
  if($doIt){
   echo '<div class="success">Account Successfully updated</div>';
  }
  else {
   echo 'unk';
  }
 }
 echo '<div class="form"><form method="post">New Email:<br/><input type="text" name="email" value="'.$daTa[1].'"/><br/>New Password:<br/><input type="password" name="pwd"/><br/><input type="submit" value="Update"/></form></div>';

 echo '<div class="back"><img src="/home.png"> <a href="index.php">Admin Home</a></div>';

 include '../foot.php';

}
else {

header('Location:login.php');
}
?>