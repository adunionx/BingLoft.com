<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - News reply");

if($adminlog==1){

 $nid=formget("id");

 $news=mysql_fetch_array(mysql_query("SELECT * FROM news WHERE id='$nid'"));
 $newsr=mysql_query("SELECT * FROM newsreplys WHERE newsid='$nid'");

if(isset($_POST['reply'])){
  $reply=formpost("reply");
  $addreply=mysql_query("INSERT INTO newsreplys (userid,msg,newsid) VALUES (0,'$reply','$nid')");
  if($addreply){
    echo '<div class="success">Reply has added!</div>';
   }
   else {
    echo 'unk';
   }
  }
 echo '<div class="title">News #'.$nid.'</div>';
 echo '<div class="form"><b>'.$news["title"].'</b><br/>'.$news["body"].'</div>';
 echo '<div class="title">Replys</div>';
 
 while($snews=mysql_fetch_array($newsr)){
  $uid=$snews["userid"];
  if($uid==0){
    $uid='ADMINSTRATOR';
  }
  echo '<div class="ad">'.$snews["msg"].'<br/>By: '.$uid.'</div>';
}

echo '<div class="form"><b>Add reply:</b><br/><form method="post"><textarea name="reply"></textarea><br/><input type="submit" value="Reply"/></form></div>';

echo '<a href="news.php"><div class="ua">All NEWS</div></a>';
include '../foot.php';
}
else {
 header('Location:login.php');
 }
?>