<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Site Stats");

if($adminlog==1){

$sid=formget("id");

$total_clicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE siteid='$sid'"));
$total_vclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE status='VALID' AND siteid='$sid'"));
$date=date("d-m-Y");
$today_clicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE time='$date' AND siteid='$sid'"));
$today_vclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE time='$date' AND status='VALID' AND siteid='$sid'"));
$total_iclicks=($total_clicks-$total_vclicks);
$today_iclicks=($today_clicks-$today_vclicks);
$total_earn=($total_vclicks*0.009);


$cp=mysql_fetch_array(mysql_query("SELECT * FROM advertises WHERE userid='640' AND status='RUNNING'"));

$cpcc=$cp["ucpc"];


$today_earn=($today_vclicks*$cpcc);

echo '<div class="title">Statistics</div>';
echo '<div class="form" align="center"><table><tr><td><div class="ad" style="padding:5px;margin:5px;"><div style="background:#ececec;padding:2px;margin:2px;" align="center"><b>Total:</b></div><div class="ad" style="padding:3.5px">Total clicks: '.$total_clicks.'<br/>Total Valid Clicks: '.$total_vclicks.'<br/>User earned total: '.$total_earn.'$</div></td><td><div class="ad" style="padding:5px;margin:5px;"><div style="background:#ececec;padding:2px;margin:2px;" align="center"><b>Today:</b></div><div class="ad" style="padding:3.5px">Today clicks: '.$today_clicks.'<br/>Today Valid Clicks: '.$today_vclicks.'<br/>User earned today: '.$today_earn.'$</div></td></tr></table></div>';

echo '<div class="title">Statistic Report</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*50;
$end=($start+50);


 $act=formget("act");
 if($act=='del') {
$sid=formget("id");
$sql=mysql_query("DELETE FROM clicks WHERE status='VALID' AND siteid='$sid'"); echo '<div class="success"> Deleted Successfully</div>'; } //end del

 if($act=='vf') {
$id=formget("id");

$uid=formget("uid");

$sql=mysql_query("UPDATE clicks SET status='VALID' WHERE id='$id'");

 $ucpc=0.009;

 $User=mysql_fetch_array(mysql_query("SELECT * FROM userdata WHERE id='$uid'"));

 $userbal=$User["pubalance"];

 $newU=($userbal+$ucpc);

 $doIt=mysql_query("UPDATE userdata SET pubalance='$newU' WHERE id='$uid'");
if($doit){
 echo '<div class="success"> update Successfully</div>';
}
 } 

//end vf
 echo '<div class="uright"><a href="?act=del&id='.$sid.'">Delete Data</a></div>';

 echo '<div class="uright"><a href="utotal-report.php?id='.$sid.'">Check Total Report</a></div>';

$stat=mysql_query("SELECT * FROM clicks WHERE siteid='$sid' ORDER BY id DESC LIMIT $start,$end");

include_once('../country/ip2country.php');
$ip2c=new ip2country();
$ip2c->mysql_host='localhost';
$ip2c->db_user='anilwapc_anil';
$ip2c->db_pass='lolbaba@9087#ak';
$ip2c->db_name='anilwapc_data';
$ip2c->table_name='ip2c';
if(mysql_num_rows($stat)>0){

echo '<div class="form"><table style="border-collapse: collapse;" align="center">
<tr>
<th class="tbl2">Date</th>
<th class="tbl2">IP</th>
<th class="tbl2">User-Agent</th>
<th class="tbl2">Country</th>
<th class="tbl2">Type</th>
<th class="tbl2">From</th>
<th class="tbl2">Ads</th>
<th class="tbl2">Site</th>
<th class="tbl2">Verify</th>
</tr>';

while($show=mysql_fetch_array($stat)){



echo '<tr>
<td class="tbl">'.$show["time"].'</td>
<td class="tbl">'.$show["ip"].'</td>
<td class="tbl">'.strstr(urldecode($show["ua"]),'(',true).'</td>
<td class="tbl">'. $ip2c->get_country_name($show["ip"]) . '</td>
<td class="tbl">'.$show["status"].'</td>
<td class="tbl"><a href="'.$show["host"].'">'.strstr(str_replace('http://',null,$show["host"]),'/',true).'</a></td>
<td class="tbl">'.$show["adtype"].'</td>
<td class="tbl"><a href="site.php?id='.$show["siteid"].'">'.$show["siteid"].'</a></td>
<td class="tbl"><a href="?act=vf&id='.$show["id"].'&uid='.$show["userid"].'">Verify</a></td>
</tr>';


}

echo '



</table></div>';

echo '<div class="uright"><a href="?page='.($start+1).'">Next</a></div>';
}
else {
echo '<div class="error">There is no clicks!</div>';
}

echo '<a href="site.php?id='.$sid.'"><div class="back">Site Details</div></a>';
include '../foot.php';
}
else{
header('Location:index.php');
}
?>