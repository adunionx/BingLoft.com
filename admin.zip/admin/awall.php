<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Block User");

if($adminlog==1){

$uid=formget("id");


 $doit=mysql_query("UPDATE wall SET status='Active' WHERE userid='$uid'");
 if($doit){
  echo '<div class="success">User is Active From Wall.</div>';
 }
 else {
  echo 'unk';
 }


 echo '<a href="user.php?id='.$uid.'"><div class="back">User Details</div></a>';
 include '../foot.php';
 }
 else {
 header('Location:login.php');
 }
 ?>