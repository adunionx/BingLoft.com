<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - User Search");

if($adminlog==1){

 $q=formget("q");

echo '<div class="title">Search result</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);


 $sdataa=mysql_query("SELECT * FROM userdata WHERE email LIKE '%$q%'  OR firstname LIKE '%$q%' OR lastname LIKE '%$q%' OR city LIKE '%$q%' OR country LIKE '%$q%' OR mobile LIKE '%$q%'  ORDER BY id DESC LIMIT $start,$end");

 if(mysql_num_rows($sdataa)>0){

while($show=mysql_fetch_array($sdataa)){

echo '<a href="user.php?id='.$show["id"].'"><div class="ua">Email: '.$show["email"].'<br/>Name: '.ucfirst($show["firstname"]).' '.ucfirst($show["lastname"]).'<br/>User ID: '.$show["id"].'</div></a>';

}

echo '<div class="ad"><a href="?page='.($start+1).'">Next</a></div>';

}
else {
echo '<div class="ad">No result found!</div>';
}


echo '<a href="index.php?goto=home"><div class="ua" align="center"><b>HOME</b></div></a>';

include '../foot.php';
}


else {

header('Location:login.php?error=session&out=no&valid=no&session=no');
}

?>


   