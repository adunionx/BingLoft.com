<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Edit Advertiser Balance");

if($adminlog==1){

 $uid=formget("id");

 $userd=mysql_fetch_array(mysql_query("SELECT * FROM userdata WHERE id='$uid'"));
 $balance=$userd["adbalance"];
 if(isset($_POST["bal"])){
   
   $newbal=formpost("bal");

   $doit=mysql_query("UPDATE userdata SET adbalance='$newbal' WHERE id='$uid'");
   if($doit){
     echo '<div class="success">New Balance has edited!</div>';
   }
   else {
     echo '<div class="error">Unknown Error!</div>';
   }
   }
  echo '<div class="form"><form method="post">New Balance:<br/><input type="text" name="bal" value="'.$balance.'"/><br/><input type="submit" value="Edit"/></form></div>';
   
 echo '<a href="user.php?id='.$uid.'"><div class="ua">Go Back</div></a>';
 include '../foot.php';
 }
 else {
  header('Location:login.php');
 }
 ?>